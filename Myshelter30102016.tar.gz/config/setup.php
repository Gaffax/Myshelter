<?php
  $dbc = mysqli_connect('');
?>
